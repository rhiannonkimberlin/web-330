$("figure").mouseleave(
    function() {
      $(this).removeClass("hover");
    }
  );